import { TestBed } from '@angular/core/testing';

import { MachineRoutineApiService } from './machine-routine-api.service';

describe('MachineRoutineApiService', () => {
  let service: MachineRoutineApiService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MachineRoutineApiService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
