import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ServiceUsuarioService } from '../services/service-usuario.service';
import { NavController, ToastController, LoadingController } from '@ionic/angular';

@Component({
  selector: 'app-password-recovery',
  templateUrl: './password-recovery.page.html',
  styleUrls: ['./password-recovery.page.scss'],
})
export class PasswordRecoveryPage implements OnInit {
  forgotPass: FormGroup;
  codeForm: FormGroup;
  resetPassForm: FormGroup;
  errorMessage: string = '';
  successMessage: string = '';
  codeRequested: boolean = false; // Control para mostrar el formulario de verificación de código
  codeVerified: boolean = false; // Control para mostrar el formulario de nueva contraseña
  email: string = '';
  isLoading: boolean = false;

  constructor(
    private navCtrl: NavController,
    private formBuilder: FormBuilder,
    private authService: ServiceUsuarioService,
    private toastController: ToastController,
    private loading: LoadingController,
  ) {
    this.forgotPass = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
    });

    this.codeForm = this.formBuilder.group({
      code: ['', [Validators.required]],
    });

    this.resetPassForm = this.formBuilder.group({
      newPassword: ['', [Validators.required, Validators.minLength(6)]],
    });
  }
  positionData: string = ''

  async presentToast(message: string, color: string = 'success', positionStr: string = 'top') {
    this.positionData = positionStr.toString();
    // Validación de valores válidos
    const validPositions: ('top' | 'bottom' | 'middle')[] = ['top', 'bottom', 'middle'];

    const toast = await this.toastController.create({
      message,
      duration: 1000,
      color,
      position: this.positionData as 'top' | 'bottom' | 'middle' // Conversión explícita de tipo
    });
    await toast.present();
  }


  async presentLoading(messageLoading: string) {
    const loading = await this.loading.create({
      message: messageLoading,
      spinner: 'circles'
    });
    await loading.present();
  }

  async dismissLoading() {
    await this.loading.dismiss();
  }
  ngOnInit() { }

  // Método para solicitar el código de recuperación
  requestCode() {
    if (this.forgotPass.invalid) {
      this.errorMessage = 'Por favor, ingrese un correo electrónico válido.';
      this.presentToast(this.errorMessage, 'danger');
      return;
    }

    const formData = this.forgotPass.value;
    this.email = formData.email;
    const body = { email: this.email };
    this.presentLoading("Validando...");
    this.authService.requestCode(body).subscribe(
      (response) => {
        this.successMessage = 'Código enviado. Por favor, revisa tu correo electrónico.';
        this.errorMessage = '';
        this.codeRequested = true;
        this.dismissLoading()
        this.presentToast(this.successMessage, 'success', 'top');
      },
      (error) => {
        this.errorMessage = error.error.message || 'Email incorrecto. Intente nuevamente.';
        this.dismissLoading()
        this.presentToast(this.errorMessage, 'danger', 'bottom');
        console.error('Error al solicitar código de recuperación', error);
      }
    );
  }

  // Método para verificar el código de recuperación
  verifyCode() {
    if (this.codeForm.invalid) {
      this.errorMessage = 'Por favor, ingrese el código de verificación.';
      this.presentToast(this.errorMessage, 'danger', 'bottom');
      return;
    }

    const formData = this.codeForm.value;
    const body = {
      email: this.email,
      recovery_code: formData.code,
    };
    this.presentLoading("Validando...");
    this.authService.verifyCode(body).subscribe(
      (response) => {
        this.successMessage = 'Código verificado correctamente. Ahora puedes restablecer tu contraseña.';
        this.errorMessage = '';
        this.codeVerified = true; // Cambia a mostrar el formulario de restablecimiento de contraseña
        this.dismissLoading()
        this.presentToast(this.successMessage, 'success', 'top');
      },
      (error) => {
        this.codeRequested = false;
        this.errorMessage = error.error.message || 'Código incorrecto o expirado. Inténtalo nuevamente.';
        this.dismissLoading()
        this.presentToast(this.errorMessage, 'danger', 'bottom');

        console.error('Error al verificar el código', error);
      }
    );
  }
  goToHome() {
    this.navCtrl.navigateForward('/home');
  }

  // Método para restablecer la contraseña
  resetPassword() {
    if (this.resetPassForm.invalid) {
      this.errorMessage = 'Por favor, ingrese una contraseña válida.';
      return;
    }

    const formData = this.resetPassForm.value;
    const body = {
      email: this.email,
      recovery_code: this.codeForm.value.code,
      new_password: formData.newPassword,
    };
    this.presentLoading("Validando...");
    this.authService.resetPassword(body).subscribe(
      (response) => {
        this.successMessage = 'Contraseña restablecida correctamente. Ahora puedes iniciar sesión.';
        this.errorMessage = '';
        this.codeRequested = false;
        this.codeVerified = false;
        this.dismissLoading();
        this.presentToast(this.successMessage, 'success', 'top');
        this.navCtrl.navigateForward('/iniciar-sesion');
      },
      (error) => {
        this.errorMessage = error.error.message || 'Hubo un problema al restablecer la contraseña. Inténtalo nuevamente.';
        if (this.errorMessage = "Código de recuperación inválido o expirado.") {
          this.codeVerified = false;
          this.codeRequested = false;
        }
        this.dismissLoading();
        this.presentToast(this.errorMessage, 'danger', 'bottom');

        console.error('Error al restablecer la contraseña', error);
      }
    );
  }
  newPasswordType: string = 'password';
  newPasswordIcon: string = 'eye-off-outline';

  toggleNewPasswordVisibility() {
    this.newPasswordType = this.newPasswordType === 'password' ? 'text' : 'password';
    this.newPasswordIcon = this.newPasswordIcon === 'eye-off-outline' ? 'eye-outline' : 'eye-off-outline';
  }

}