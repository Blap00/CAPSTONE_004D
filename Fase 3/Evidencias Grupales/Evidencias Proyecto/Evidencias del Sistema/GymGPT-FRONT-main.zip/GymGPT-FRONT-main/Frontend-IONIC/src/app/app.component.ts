import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';
import { Router } from '@angular/router';
import { ServiceUsuarioService } from './services/service-usuario.service';
import { AdmobService } from './services/admob.service';
import { AlertController, NavController } from '@ionic/angular';

interface Componente {
  icon: string;
  name: string;
  redirecTo: string;
}

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent implements OnInit {
  user: any;
  isLogged: boolean = false;
  media_url = '';
  statusImage: boolean = false;
  baseUrl: string = 'https://fabianpalma000.pythonanywhere.com/';
  handlerMessage = '';
  
  private allowedAdRoutes = ['/inicio', '/machine-info']; // Rutas donde se permiten los anuncios

  constructor(
    private userService: ServiceUsuarioService,
    private menuController: MenuController,
    private alertController: AlertController,
    private router: Router,
    private navController: NavController,
    private admobService: AdmobService
  ) {
    this.router.events.subscribe(() => {
      this.onMenuClose();
    });
  }

  ngOnInit() {
    const userId = localStorage.getItem('userId');
    if (userId) {
      this.isLogged = true;
      this.userService.getUser(parseInt(userId)).subscribe(
        data => {
          this.user = data;
          this.media_url = this.user.user.image || '';
          this.statusImage = !!this.media_url;
          this.user.user.image = this.statusImage
            ? `${this.baseUrl}${this.media_url}`
            : '';
        },
        error => console.error('Error al obtener los datos del usuario:', error)
      );
    }
  }

  isLoggedFunc(): boolean {
    const userId = localStorage.getItem('userId');
    this.isLogged = !!userId;
    return this.isLogged;
  }

  async alertapro() {
    const alert = await this.alertController.create({
      header: '¿Estás Seguro?',
      message: 'Al cerrar la sesión volverás al inicio de registro.',
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel',
        },
        {
          text: 'Ok',
          role: 'confirm',
          handler: () => this.cerrarSesion(),
        },
      ],
    });
    await alert.present();
  }

  cerrarSesion() {
    this.isLogged = false;
    this.menuController.enable(false, 'first');
    this.router.navigateByUrl('/home').then(() => {
      localStorage.clear();
    });
  }

  async onMenuOpen() {
    try {
      await this.admobService.hideBanner();
    } catch {
      console.error('No se logró ocultar el banner');
    }
  }
  // async onMenuClose() {
  //   try {
  //     await this.admobService.resumeBanner();
  //   } catch {
  //     console.error('No se logró mostrar el banner');
  //   }
  // }
  async onMenuClose() {
    const currentRoute = this.router.url;
    if (this.allowedAdRoutes.includes(currentRoute)) {
      try {
        this.admobService.resumeBanner();
      } catch {
        console.error('No se logró mostrar ningún banner');
      }
    } else {
      try {
        this.admobService.hideBanner();
      } catch {
        console.error('No hay banner que ocultar');
      }
    }
  }

  componentes: Componente[] = [
    { icon: 'home-outline', name: 'Inicio', redirecTo: '/inicio' },
    { icon: 'camera-outline', name: 'Cámara', redirecTo: '/camara' },
    { icon: 'star-outline', name: 'Sugerencias', redirecTo: '/sugerencias' },
    { icon: 'person-outline', name: 'Perfil', redirecTo: '/user' },
    // { icon: 'cog-outline', name: 'Configuración', redirecTo: '/config' },
  ];

  componentes1: Componente[] = [
    { icon: 'exit-outline', name: 'Cerrar sesión', redirecTo: '/home' },
  ];
}