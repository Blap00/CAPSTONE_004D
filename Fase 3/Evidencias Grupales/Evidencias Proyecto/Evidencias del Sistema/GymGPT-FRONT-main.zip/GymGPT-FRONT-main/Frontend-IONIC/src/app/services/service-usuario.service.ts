import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ServiceUsuarioService {
  baseUrl: string = environment.baseUrl;
  private apiUrl = this.baseUrl + 'api/v-1/'; // Cambia esta URL según tu backend

  constructor(private http: HttpClient) { }

  // Método para registrar un nuevo usuario
  registerUser(userData: any): Observable<any> {
    return this.http.post(`${this.apiUrl}register/`, userData);
  }

  // Método para loguear el usuario
  loginUser(body: any): Observable<any> {
    return this.http.post(`${this.apiUrl}login/`, body);
  }

  requestCode(body: any): Observable<any> {
    return this.http.post(`${this.apiUrl}request_password_recovery/`, body);
  }

  // Método para verificar el código de recuperación
  verifyCode(body: any): Observable<any> {
    return this.http.post(`${this.apiUrl}verify_code/`, body);
  }

  getUser(id: number): Observable<any> {
    return this.http.get(`${this.apiUrl}getuser/${id}`);
  }

  getToken(body: any): Observable<any> {
    return this.http.post(`${this.baseUrl}api/token/`, body);
  }

  postFeedback(body: any): Observable<any> {
    const token = localStorage.getItem('token');
    if (!token) {
      console.error('Token no encontrado');
    }
    return this.http.post(`${this.apiUrl}feedback/create/`, body, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      }
    });
  }
  refreshedToken(refreshToken: string): Observable<any> {
    const body = {
      refresh: refreshToken
    };

    return this.http.post(`${this.baseUrl}api/token/refresh/`, body).pipe(
      tap((response: any) => {
        // Asegúrate de que el backend devuelva el nuevo token en el campo `access`
        if (response && response.access) {
          // Actualiza los valores en localStorage
          localStorage.setItem('token', response.access);

          if (response.refresh) {
            localStorage.setItem('refresh', response.refresh); // Si también devuelve un refresh token
          }
        }
      }),
      catchError(error => {
        console.error('Error al refrescar el token:', error);
        return throwError(() => new Error('Error al refrescar el token'));
      })
    );
  }
  getLastRoutine(id: number): Observable<any> {
    const token = localStorage.getItem('token');  // Asegúrate de que el token se almacene correctamente

    const refreshToken = localStorage.getItem('refresh');  // Asegúrate de que el token se almacene correctamente
    this.refreshedToken(refreshToken);


    return this.http.get(`${this.apiUrl}routine/infoBy/${id}/all`, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    })


  }

  // Actualizar perfil de usuario
  updateUserWithImage(FormData: FormData): Observable<any> {
    const token = localStorage.getItem('token');  // Asegúrate de que el token se almacene correctamente
    if (!token) {
      console.error('Token no encontrado');
    }
    return this.http.put(`${this.apiUrl}edit-profile/`, FormData, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
  }

  resetPassword(body: any): Observable<any> {
    return this.http.post(`${this.apiUrl}reset_password/`, body);
  }
}