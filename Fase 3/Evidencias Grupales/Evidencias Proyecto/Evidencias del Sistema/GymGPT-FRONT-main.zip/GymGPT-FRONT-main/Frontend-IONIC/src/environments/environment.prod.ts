import { privateurls } from "./privateurls";
export const environment = {
  production: true,
  baseUrl: privateurls.BaseURL,
  visionEndPointUrl: privateurls.customVisionEndpoint,
  customVisionApiKey: privateurls.customVisionApiKey,
};
