import { Component, OnInit, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { ServiceUsuarioService } from '../services/service-usuario.service';
import { MachineRoutineApiService } from '../services/machine-routine-api.service';
import { MenuController, NavController, ToastController, LoadingController } from '@ionic/angular';
import { AppComponent } from '../app.component';
import * as cocoSsd from '@tensorflow-models/coco-ssd';
import * as tf from '@tensorflow/tfjs';
import { environment } from '../../environments/environment.development';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Subscription } from 'rxjs';


@Component({
  selector: 'app-camara',
  templateUrl: './camara.page.html',
  styleUrls: ['./camara.page.scss'],
})
export class CamaraPage implements OnInit, OnDestroy {
  @ViewChild('videoElement', { static: false }) videoElement!: ElementRef<HTMLVideoElement>;
  @ViewChild('canvasElement', { static: false }) canvasElement!: ElementRef<HTMLCanvasElement>;

  user: any = {
    "user": { "id": -1, "username": "", "email": "", "first_name": "", "last_name": "", "height": 0, "age": 0, "weight": 0, "routines": [], "image": "" }
  };

  // Subscription para solicitudes HTTP
  azureRequestSubscription!: Subscription;
  model!: cocoSsd.ObjectDetection;
  detectedObject: string | null = null;
  customVisionEndpoint = environment.visionEndPointUrl;
  customVisionApiKey = environment.customVisionApiKey;
  componente = this.appComponent.componentes;
  media_url = '';
  statusImage = false;
  baseUrl: string = environment.baseUrl;
  isCameraActive: boolean = false;
  isLoading: boolean = false;
  positionData: string = '';
  // Variables para el selector de dificultad y el botón
  dificultadSeleccionada: string | null = null;
  botonHabilitado = false;
  errorMessage: string = '';

  constructor(
    private http: HttpClient,
    private userService: ServiceUsuarioService,
    private menuController: MenuController,
    private navController: NavController,
    private appComponent: AppComponent,
    private machineAPI: MachineRoutineApiService,
    private toastController: ToastController,
    private loading: LoadingController,
  ) { }
  async loadCustomData() {
    this.baseUrl = environment.baseUrl;
    this.customVisionEndpoint = environment.visionEndPointUrl;
    this.customVisionApiKey = environment.customVisionApiKey;
    this.componente = this.appComponent.componentes;
  }
  async ngOnInit() {
    await this.initializeTensorFlowModel();
    this.loadUserData();
    this.openCamera();
    this.loadCustomData();
  }

  private async initializeTensorFlowModel() {
    try {
      await tf.setBackend('webgl').catch(async () => await tf.setBackend('cpu'));
      await tf.ready();
      this.model = await cocoSsd.load();
      console.log('Modelo coco-ssd cargado.');
    } catch (error) {
      console.error('Error al cargar TensorFlow:', error);
    }
  }

  private loadUserData() {
    const userId = localStorage.getItem('userId');
    if (userId) {
      this.userService.getUser(parseInt(userId)).subscribe(
        (data) => {
          this.user = data;
          this.media_url = this.user.user.image;
          this.statusImage = true;
          if (this.user.user.image != '' || this.media_url != undefined) {
            this.user.user.image = `${this.baseUrl}${this.media_url}`;
          }else{
            this.user.user.image = `${this.baseUrl}${this.media_url}media/ryan.jpg`
          }
          console.log('Datos del usuario:', this.user);
        },
        (error) => console.error('Error al obtener los datos del usuario:', error)
      );
    } else {
      console.error('No hay un usuario conectado');
    }
  }

  async openCamera() {
    this.detectedObject = null;
    this.isCameraActive = true;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" }
      });
      this.videoElement.nativeElement.srcObject = stream;
      this.videoElement.nativeElement.onloadedmetadata = () => {
        this.videoElement.nativeElement.play();

        const videoWidth = this.videoElement.nativeElement.videoWidth;
        const videoHeight = this.videoElement.nativeElement.videoHeight;

        this.canvasElement.nativeElement.width = videoWidth;
        this.canvasElement.nativeElement.height = videoHeight;
        console.log(videoHeight + " x " + videoWidth);
      };
      this.detectFromVideo();
      setInterval(() => {
        this.sendToCustomVision();
      }, 1000);
    } catch (error) {
      console.error('Error al activar la cámara:', error);
    }
  }

  async detectFromVideo() {
    if (this.videoElement.nativeElement.readyState >= 2) {
      const predictions = await this.model.detect(this.videoElement.nativeElement);
      this.renderPredictions(predictions);
      requestAnimationFrame(() => this.detectFromVideo());
    }
  }

  renderPredictions(predictions: cocoSsd.DetectedObject[]) {
    const canvas = this.canvasElement.nativeElement;
    const context = canvas.getContext('2d');
    if (context) {
      context.clearRect(0, 0, canvas.width, canvas.height);
      if (predictions.length > 0) {
        const highestConfidencePrediction = predictions.reduce((prev, current) =>
          (prev.score > current.score) ? prev : current
        );
        this.detectedObject = highestConfidencePrediction.class;
        const [x, y, width, height] = highestConfidencePrediction.bbox;

        context.strokeStyle = 'red';
        context.lineWidth = 3;
        context.strokeRect(x, y, width, height);

        context.font = '16px Arial';
        context.fillStyle = 'red';
        context.fillText(this.detectedObject, x, y > 10 ? y - 5 : y + 15);
      }
    }
  }
  thisObject:any;
  async sendToCustomVision() {
    if (!this.videoElement.nativeElement) return;
  
    const canvas = document.createElement('canvas');
    canvas.width = this.videoElement.nativeElement.videoWidth;
    canvas.height = this.videoElement.nativeElement.videoHeight;
    const context = canvas.getContext('2d');
  
    if (context) {
      context.drawImage(this.videoElement.nativeElement, 0, 0, canvas.width, canvas.height);
    }
  
    const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve));
  
    if (blob) {
      const headers = new HttpHeaders({
        'Prediction-Key': this.customVisionApiKey,
        'Content-Type': 'application/octet-stream',
      });
  
      // Guarda la suscripción para poder cancelar si es necesario
      this.azureRequestSubscription = this.http.post(this.customVisionEndpoint, blob, { headers }).subscribe(
        (result: any) => {
          
          // Verifica si hay predicciones
          if (result?.predictions?.length > 0) {
            // Filtra las predicciones para obtener solo aquellas con una probabilidad mayor o igual al 80%
            const filteredPredictions = result.predictions.filter((prediction: any) => prediction.probability >= 0.95 );
  
            // Verifica si existen predicciones con alta probabilidad
            if (filteredPredictions.length > 0) {
              // Encuentra la predicción con la mayor probabilidad
              const highestConfidencePrediction = filteredPredictions.reduce((prev: any, current: any) =>
                prev.probability > current.probability ? prev : current
              );
              
              // Asigna el objeto detectado y su probabilidad
              this.detectedObject = highestConfidencePrediction.tagName;
              console.log('Objeto detectado con alta confianza:', this.detectedObject, 'Confianza:', highestConfidencePrediction.probability);
            } else {
              // Si no hay predicciones con suficiente confianza
              this.detectedObject = 'No se ha identificado la maquina.'
              console.warn('No se encontraron predicciones con confianza >= 95%.');
            }
          } else {
            console.warn('No se encontraron predicciones en la respuesta.');
          }
        },
        (error) => {
          console.error('Error al enviar imagen a Azure:', error);
        }
      );
    }
  }
  

  mostrarMenu() {
    this.menuController.open('first');
    this.menuController.enable(true, 'first');
  }

  stopCamera() {
    const videoElement = this.videoElement.nativeElement;

    // Detiene las pistas de la cámara
    const stream = videoElement.srcObject as MediaStream;
    if (stream) {
      stream.getTracks().forEach(track => {
        track.stop(); // Detiene cada pista
        console.log(`Pista de ${track.kind} detenida:`, track);
      });
    }

    // Elimina la referencia del flujo de la cámara
    videoElement.srcObject = null;
    this.isCameraActive = false;
    console.log("Cámara detenida y referencia eliminada.");
  }

  // Método del ciclo de vida de Ionic para detener procesos al salir
  ionViewWillLeave() {
    this.stopCamera();

    // Cancela solicitudes pendientes a Azure
    if (this.azureRequestSubscription) {
      this.azureRequestSubscription.unsubscribe();
      console.log('Solicitud a Azure cancelada.');
    }
  }

  ngOnDestroy() {
    this.stopCamera();
    console.log("ngOnDestroy llamado, la cámara debería estar cerrada.");
  }

  async presentLoading(messageLoading: string) {
    const loading = await this.loading.create({
      message: messageLoading,
      spinner: 'circles'
    });
    await loading.present();
  }

  async dismissLoading() {
    await this.loading.dismiss();
  }

  async presentToast(message: string, color: string = 'success', positionStr: string = 'top') {
    this.positionData = positionStr.toString();
    // Validación de valores válidos
    const validPositions: ('top' | 'bottom' | 'middle')[] = ['top', 'bottom', 'middle'];

    const toast = await this.toastController.create({
      message,
      duration: 1000,
      color,
      position: this.positionData as 'top' | 'bottom' | 'middle' // Conversión explícita de tipo
    });
    await toast.present();
  }

  // Métodos para el selector de dificultad y el botón
  habilitarBoton() {
    this.botonHabilitado = this.dificultadSeleccionada !== null;
  }
  body: any = {};
  mostrarInfoMaquina() {
    console.log('Dificultad seleccionada:', this.dificultadSeleccionada);
    if (this.detectedObject && this.dificultadSeleccionada) {
      const body = {
        difficult: this.dificultadSeleccionada,
        machine_type: this.detectedObject,
      }
      this.presentLoading("Validando...");
      this.machineAPI.postCameraMachine(body).subscribe(
        (response) => {
          this.dismissLoading()
          this.navController.navigateForward('/machine-info')
        },
        (error) => {
          this.errorMessage = error.error.message || 'Código incorrecto o expirado. Inténtalo nuevamente.';
          this.dismissLoading()
          this.presentToast(this.errorMessage, 'danger', 'bottom');

          console.error('Error al Scanear la maquina', error);
        }
      )

    }
  }
}