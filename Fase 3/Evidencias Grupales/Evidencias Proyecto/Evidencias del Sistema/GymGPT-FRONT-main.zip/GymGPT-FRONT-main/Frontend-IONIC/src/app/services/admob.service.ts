import { Injectable } from '@angular/core';
import { AdMob, 
  BannerAdOptions, 
  BannerAdPosition, 
  RewardAdOptions, 
  AdOptions, 
  BannerAdSize,
  AdMobBannerSize,
  AdMobInitializationOptions} from '@capacitor-community/admob';
import { isPlatform } from '@ionic/angular';

@Injectable({
  providedIn: 'root'
})
export class AdmobService {

  constructor() {
    // Inicializar AdMob
    this.initializeAdMob();
  }

  async initializeAdMob() {
    const { status }= await AdMob.trackingAuthorizationStatus();
    console.log(status)
    if(status === 'notDetermined'){
      console.log("Muestra la información despues de que cargue la data")
    }
    try {
      AdMob.initialize({
        initializeForTesting:true
      });
      console.log('AdMob inicializado correctamente');
    } catch (error) {
      console.error('Error inicializando AdMob:', error);
    }
  }

  async showBanner() {
    const adId = isPlatform('ios')? 'ios-ad-id': 'android-ad-unit'
    const options: BannerAdOptions = {
      adId: 'ca-app-pub-6780294602269855~7683950914', // Reemplaza con tu ID de Banner // ca-app-pub-6780294602269855/8828246271
      adSize: BannerAdSize.ADAPTIVE_BANNER,
      position: BannerAdPosition.TOP_CENTER, 
      margin: 100,  
      npa: true,
      isTesting: true, // Cambia a falso en producción
    };


    try {
      await AdMob.showBanner(options);
    } catch (error) {
      console.error('Error mostrando banner:', error);
    }
  }

  async hideBanner() {
    try {
      await AdMob.hideBanner();
    } catch (error) {
      console.error('Error ocultando banner:', error);
    }
  }

  async resumeBanner(){
    try{
      await AdMob.resumeBanner();
    }catch(error){
      console.error('Error al resumir el Banner: ', error)
    }
  }

  async showInterstitial() {
    const options: AdOptions = {
      adId: 'ca-app-pub-3461248869312078/5239520903', // Reemplaza con tu ID de Interstitial
      isTesting: true, // Cambia a falso en producción
    };

    try {
      await AdMob.prepareInterstitial(options);
      await AdMob.showInterstitial();
    } catch (error) {
      console.error('Error mostrando interstitial:', error);
    }
  }

  async showRewardedAd() {
    const options: RewardAdOptions = {
      adId: 'ca-app-pub-3461248869312078/6709942293', // Reemplaza con tu ID de Rewarded
      isTesting: true, // Cambia a falso en producción
    };

    try {
      await AdMob.prepareRewardVideoAd(options);
      await AdMob.showRewardVideoAd();
    } catch (error) {
      console.error('Error mostrando rewarded ad:', error);
    }
  }
}