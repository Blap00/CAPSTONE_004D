import { Component } from '@angular/core';
import { NavController, ToastController } from '@ionic/angular';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ServiceUsuarioService } from '../services/service-usuario.service'; // Asegúrate de que esta ruta sea correcta

@Component({
  selector: 'app-iniciar-sesion',
  templateUrl: './iniciar-sesion.page.html',
  styleUrls: ['./iniciar-sesion.page.scss'],
})
export class IniciarSesionPage {
  loginForm: FormGroup;
  errorMessage: string = '';
  passwordType: string = 'password';
  passwordIcon: string = 'eye-off-outline';

  constructor(
    private navCtrl: NavController,
    private formBuilder: FormBuilder,
    private authService: ServiceUsuarioService,
    private toast: ToastController,
  ) {
    this.loginForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
    });
  }

  async presentToast(message: string, color: 'success' | 'danger') {
    const toast = await this.toast.create({
      message: message,
      duration: 3000, // Duración en milisegundos
      position: 'top',
      color: color
    });
    toast.present();
  }

  goToRegistrarse() {
    this.navCtrl.navigateForward('/registrarse');
  }
  goToPagMain() {
    this.navCtrl.navigateForward('/pagina-principal');
  }
  goToForgotAPass(){
    this.navCtrl.navigateForward('/password-recovery')
  }
  goToHome() {
    this.navCtrl.navigateForward('/home');
  }
  goToInicio() {
    this.navCtrl.navigateForward('/inicio');
  }
  username: string = '';
  async login() {
    if (this.loginForm.invalid) {
      this.errorMessage = 'Por favor, complete todos los campos correctamente.';
      this.presentToast(this.errorMessage, 'danger');
      return;
    }

    const formData = this.loginForm.value;
    const body = {
      email: formData.email,
      password: formData.password,
    };
    this.username = body.email.split('@')[0]
    this.authService.loginUser(body).subscribe(
      (response) => {
        localStorage.removeItem('userId'); // Limpia el localStorage
        const userId = response.user; // Ajusta según tu respuesta de la API
        localStorage.setItem('userId', userId); // Guarda la ID en localStorage
        localStorage.removeItem('token'); // Limpia el localStorage
        console.log("Inicio");

        const tokenRequestBody = {
          username: this.username,
          password: body.password
        };

        this.authService.getToken(tokenRequestBody).subscribe(
          (tokenResponse: any) => {
            const token = tokenResponse.access; // Ajusta según tu respuesta
            const refreshToken = tokenResponse.refresh;
            localStorage.setItem('token', token);
            localStorage.setItem('refresh', refreshToken);
            this.presentToast('Inicio de sesión exitoso', 'success');
            this.goToInicio();
            console.log("Inicio Exitoso con credenciales: "+body);
            this.goToInicio();
          },
          (error) => {
            console.error('Error al obtener el token', error);
            this.errorMessage = 'Error al obtener el token.';
          }
        );
      },
      (error) => {
        // Mejora el manejo de errores para mostrar mensajes más específicos
        if (error.status === 400) {
          this.errorMessage = error.error.errors || 'Error en las credenciales. Por favor, verifica e intenta nuevamente.';
        } else {
          this.errorMessage = 'Error inesperado al iniciar sesión. Intenta nuevamente.';
        }
        this.presentToast(error.error.message || 'Credenciales incorrectas. Inténtalo de nuevo.', 'danger');

      }
    );
  }
  togglePasswordVisibility() {
    if (this.passwordType === 'password') {
      this.passwordType = 'text';
      this.passwordIcon = 'eye-outline';
    } else {
      this.passwordType = 'password';
      this.passwordIcon = 'eye-off-outline';
    }
  }
  goToPasswordRecovery() {
    this.navCtrl.navigateForward('/password-recovery');
  }
}