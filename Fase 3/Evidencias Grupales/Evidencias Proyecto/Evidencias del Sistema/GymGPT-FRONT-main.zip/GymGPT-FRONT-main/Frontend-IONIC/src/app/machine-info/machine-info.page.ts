import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ServiceUsuarioService } from '../services/service-usuario.service';
import { NavController, ToastController, LoadingController, MenuController } from '@ionic/angular';
import { environment } from '../../environments/environment';
import { AppComponent } from '../app.component';
import { MachineRoutineApiService } from '../services/machine-routine-api.service';
import { AdmobService } from '../services/admob.service';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

@Component({
  selector: 'app-machine-info',
  templateUrl: './machine-info.page.html',
  styleUrls: ['./machine-info.page.scss'],
})
export class MachineInfoPage implements OnInit {

  errorMessage: string = '';
  successMessage: string = '';
  isLoading: boolean = false;
  user: any;
  subscription:boolean=false;
  baseUrl: string = environment.baseUrl;
  constructor(
    // private navCtrl: NavController,
    // private formBuilder: FormBuilder,
    private userService: ServiceUsuarioService,
    private toastController: ToastController,
    private loading: LoadingController,
    private appComponent: AppComponent,
    private menuController: MenuController,
    private machineAPI: MachineRoutineApiService,
    private admobService: AdmobService,
    private sanitizer: DomSanitizer
  ) { }
  componente = this.appComponent.componentes;
  media_url = ''
  statusImage: boolean = false
  ngOnInit() {
    this.loadDataUser();
    this.loadLastMachine();
    this.reloadBanner();
  }
  sanitizeContent(rawContent: string): SafeHtml {
    return this.sanitizer.bypassSecurityTrustHtml(rawContent);
  }
  ionViewDidEnter(){
    this.admobService.resumeBanner();
  }
  async initializeApp(){
    this.admobService.initializeAdMob().then(() => {
      this.admobService.showBanner();
    }).catch(error => {
      console.error('Error al inicializar AdMob o mostrar el banner:', error);
    });
  }

  async reloadBanner(){
    this.admobService.resumeBanner();
  }

  async loadDataUser() {
    const userId = localStorage.getItem('userId');
    if (userId) {
      this.userService.getUser(parseInt(userId)).subscribe(
        data => {
          this.user = data;
          this.media_url = this.user.user.image
          if (this.user.user.image != '' && this.media_url != undefined) {
            this.user.user.image = `${this.baseUrl}${this.media_url}`;
            this.statusImage = true
          } else {
            console.log("La imagen no se encontro!")
            this.statusImage = true
            this.user.user.image = `${this.baseUrl}${this.media_url}media/ryan.jpg`
          }
          if(this.user.user.subscription==true){
            this.subscription=true;
          }else{
            this.subscription=false;
          }
        },
        error => {
          console.error('Error al obtener los datos del usuario:', error);
        }
      );
    } else {
      console.error('No hay un usuario conectado');
    }
  }

  machineTitle: string = '';
  machineType: SafeHtml;
  machineInfo: SafeHtml;
  dataCreate: Date;
  message: SafeHtml;
  async loadLastMachine() {
    const userId = localStorage.getItem('userId');
    if (userId) {
      this.machineAPI.getLastMachine(parseInt(userId)).subscribe(
        data => {
          this.machineTitle = data.Machine_name;
          this.machineType = this.sanitizeContent(data.Machine_type || '');
          this.machineInfo = this.sanitizeContent(data.Machine_info || '');
          this.dataCreate = new Date(data.Created_at);
          this.message = this.sanitizeContent(data.message || '');

          console.log('Título:', this.machineTitle);
          console.log('Tipo:', this.machineType);
          console.log('Información:', this.machineInfo);
          console.log('Creado:', this.dataCreate);
          console.log('Mensaje:', this.message);
        },
        error => {
          console.error('Error al obtener datos:', error);
        }
      );
    }
  }

  positionData: string = '';
  ionViewDidLeave(){
    this.admobService.hideBanner
  }
  async presentToast(message: string, color: string = 'success', positionStr: string = 'top') {
    this.positionData = positionStr.toString();
    // Validación de valores válidos
    const validPositions: ('top' | 'bottom' | 'middle')[] = ['top', 'bottom', 'middle'];

    const toast = await this.toastController.create({
      message,
      duration: 1000,
      color,
      position: this.positionData as 'top' | 'bottom' | 'middle' // Conversión explícita de tipo
    });
    await toast.present();
  }


  async presentLoading(messageLoading: string) {
    const loading = await this.loading.create({
      message: messageLoading,
      spinner: 'circles'
    });
    await loading.present();
  }

  async dismissLoading() {
    await this.loading.dismiss();
  }
  mostrarMenu() {
    // Oculta el banner cuando se abre el menú
    this.admobService.hideBanner();
    this.menuController.open('first');
    this.menuController.enable(true, 'first');
  }
  
  cerrarMenu() {
    // Reactiva el banner al cerrar el menú
    this.menuController.close('first').then(() => {
      this.admobService.showBanner();
    });
  }
  async showBanner(){
    this.admobService.showBanner()
  }
}