import { privateurls } from "./privateurls";

export const environment = {
  production: true,
  baseUrl : privateurls.BaseURL, // Ajusta esto según tu entorno
  visionEndPointUrl: privateurls.customVisionEndpoint,
  customVisionApiKey: privateurls.customVisionApiKey,
};