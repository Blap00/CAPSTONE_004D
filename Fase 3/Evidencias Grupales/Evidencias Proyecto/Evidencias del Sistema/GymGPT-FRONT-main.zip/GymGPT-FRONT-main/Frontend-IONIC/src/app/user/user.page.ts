import { Component, OnInit } from '@angular/core';
import { ServiceUsuarioService } from '../services/service-usuario.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MenuController, NavController, ToastController, LoadingController } from '@ionic/angular';
import { AppComponent } from '../app.component';
import { environment } from '../../environments/environment';
import { MachineRoutineApiService } from '../services/machine-routine-api.service';
@Component({
  selector: 'app-user',
  templateUrl: './user.page.html',
  styleUrls: ['./user.page.scss'],
})
export class UserPage implements OnInit {
  user: any;
  routines: string[] = [];
  selectedRoutine: string;

  baseUrl: string = environment.baseUrl;

  isLoading: boolean = false;
  positionData: string = '';
  constructor(
    private userService: ServiceUsuarioService,
    private formBuilder: FormBuilder,
    private menuController: MenuController,
    private navController: NavController,
    private appComponent: AppComponent,
    private routineAPI: MachineRoutineApiService,
    private toastController: ToastController,
    private loading: LoadingController,
  ) {
  }
  async presentLoading(messageLoading: string) {
    this.isLoading=true;
    const loading = await this.loading.create({
      message: messageLoading,
      spinner: 'circles'
    });
    await loading.present();
  }

  async dismissLoading() {
    this.isLoading=false;
    await this.loading.dismiss();
  }

  async presentToast(message: string, color: string = 'success', positionStr: string = 'top') {
    this.positionData = positionStr.toString();
    // Validación de valores válidos
    const validPositions: ('top' | 'bottom' | 'middle')[] = ['top', 'bottom', 'middle'];

    const toast = await this.toastController.create({
      message,
      duration: 1000,
      color,
      position: this.positionData as 'top' | 'bottom' | 'middle' // Conversión explícita de tipo
    });
    await toast.present();
  }


  componente = this.appComponent.componentes;
  media_url = ''
  statusImage:boolean = false


  ngOnInit() {
    const userId = localStorage.getItem('userId');
    if (userId) {
      this.userService.getUser(parseInt(userId)).subscribe(
        data => {
          this.user = data;
          this.media_url = this.user.user.image
          if(this.user.user.image!='' && this.media_url!=undefined){
            this.user.user.image = `${this.baseUrl}${this.media_url}`;
            this.statusImage=true
          }else{
            console.log("La imagen no se encontro!")
            this.statusImage=true
            this.user.user.image = `${this.baseUrl}${this.media_url}media/ryan.jpg`
          }
          console.log('Datos del usuario:', this.user);
          this.dismissLoading();
        },
        error => {
          console.error('Error al obtener los datos del usuario:', error);
          this.dismissLoading();
        }
      );
    } else {
      console.error('No hay un usuario conectado');
    }
    this.getRoutines();
    this.getLastRoutines();
    // console.log(this.getRoutines)
  }
  abrirPerfil(){
    this.navController.navigateForward('/edit-user')
  }
  guardarRoutine(){
    if (this.selectedRoutine) {  // Verifica si se ha seleccionado una rutina
      const body = {
        routine: this.selectedRoutine
      };
      this.presentLoading('Guardando')
      this.routineAPI.postRoutine(body).subscribe(
        data => {
          console.log('Rutina creada:', data);
          this.presentToast('¡Rutina Guardada!', 'success', 'bottom')
          this.dismissLoading()
        },
        error => {
          this.presentToast('Error al guardar, '+error, 'danger', 'bottom' )
          this.dismissLoading()
          console.error('Error al crear la rutina:', error);
        }
      )
    }
  }
  excersice:string ='';
  time:string='';
  username:string='';
  dataPresent:boolean=false;
  dataSTR:string = '';
  getLastRoutines() {
    const userId = localStorage.getItem('userId');
    if (userId) {
      this.presentLoading('Cargando rutinas')
      this.routineAPI.getRoutineData(parseInt(userId)).subscribe(
        data => {
          this.dataPresent = true;
          this.time = data.Duracion;
          this.excersice = data.Ejercicio;
          this.username = data.NomUsuario;
          this.isLoading=false;
          this.dismissLoading();
          // Asigna la rutina actual del usuario como la seleccionada
          this.selectedRoutine = data.Rutina || ''; // Asume que `data.Rutina` contiene el nombre de la rutina actual
          console.log(this.selectedRoutine);
          this.dataSTR ='¡Rutina cargada!';
          console.log(this.dataSTR);
          // this.presentToast(this.dataSTR, 'success', 'bottom');
          // this.dismissLoading();

        },
        error => {
          this.dataPresent = false;
          this.dataSTR ='Error al cargar los datos de la rutina '+error;
          // this.presentToast(this.dataSTR, 'danger', 'bottom');
          this.dismissLoading();
          console.error(this.dataSTR, error);

        }
      );
    }
  }
  getRoutines() {
    this.routineAPI.getBucketList().subscribe(
      (data) => {
        this.routines = data;
      },
      (error) => {
        console.error('Error al cargar rutinas', error);
      }
    );
  }

  mostrarMenu() {
    this.menuController.open('first');
    this.menuController.enable(true, 'first');
  }
}