import { Component, OnInit } from '@angular/core';
import { ServiceUsuarioService } from '../services/service-usuario.service';
import { NavController, ToastController, LoadingController } from '@ionic/angular';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-registrarse',
  templateUrl: './registrarse.page.html',
  styleUrls: ['./registrarse.page.scss'],
})
export class RegistrarsePage {

  // Definicion de objeto a mandar al Back mediante REST CONNECTION

  registerForm: FormGroup;
  errorMessage: string = '';
  isLoading: boolean = false;
  successMessage: string = '';


  constructor(private formBuilder: FormBuilder,
    private authService: ServiceUsuarioService,
    private navCtrl: NavController,
    private toastController: ToastController,
    private loading: LoadingController,) {
    this.registerForm = this.formBuilder.group({
      username: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.email]],
      pass1: ['', [Validators.required, Validators.minLength(6)]],
      pass2: ['', [Validators.required]],
      terms: [false, Validators.requiredTrue] // Checkbox para términos
    });
  }

  goToIniciarSesion() {
    this.navCtrl.navigateForward('/iniciar-sesion')
  }

  goToRegistrarse() {
    this.navCtrl.navigateForward('/registrarse')
  }
  goToHome() {
    this.navCtrl.navigateForward('/home')
  }

  /****************
   * Metodo Asincronos
   ****************/
  positionData: string = ''

  async presentToast(message: string, color: string = 'success', positionStr: string = 'top') {
    this.positionData = positionStr.toString();
    // Validación de valores válidos
    const validPositions: ('top' | 'bottom' | 'middle')[] = ['top', 'bottom', 'middle'];

    const toast = await this.toastController.create({
      message,
      duration: 1000,
      color,
      position: this.positionData as 'top' | 'bottom' | 'middle' // Conversión explícita de tipo
    });
    await toast.present();
  }


  async presentLoading(messageLoading: string) {
    const loading = await this.loading.create({
      message: messageLoading,
      spinner: 'circles'
    });
    await loading.present();
  }

  async dismissLoading() {
    await this.loading.dismiss();
  }

  /****************
   * METODOS
   ****************/
  validatePasswords(): boolean {
    const pass1 = this.registerForm.get('pass1')?.value;
    const pass2 = this.registerForm.get('pass2')?.value;
    return pass1 === pass2;
  }

  register() {
    if (!this.validatePasswords()) {
      this.errorMessage = 'Las contraseñas no coinciden';
      this.presentToast(this.errorMessage, 'danger', 'bottom');
      return;
    }
    if (this.registerForm.invalid) {
      this.errorMessage = 'Por favor, complete todos los campos correctamente.';
      this.presentToast(this.errorMessage, 'danger', 'bottom');
      return;
    }
    const formData = this.registerForm.value;
    const fullName = formData.username.split(" ");

    // Asignar primer y segundo nombre (o apellido)
    formData.first_name = fullName[0];  // Primer nombre
    formData.last_name = fullName.length > 1 ? fullName.slice(1).join(" ") : "";  // Si hay más de un nombre, el resto se considera apellido
    const body = {
      first_name: formData.first_name,
      last_name: formData.last_name,
      email: formData.email,
      password: formData.pass1,
      password2: formData.pass2,
    };
    this.presentLoading("Registrando...");
    this.authService.registerUser(body).subscribe(
      (response) => {
        this.successMessage = 'Usuario registrado exitosamente';
        // Redirigir al login o dashboard después del registro
        this.dismissLoading()
        this.presentToast(this.successMessage, 'success', 'top');
        this.goToIniciarSesion();
      },
      (error) => {
        this.dismissLoading()
        this.presentToast(this.successMessage, 'danger', 'bottom');
        console.error('Error al registrar el usuario', error);
      }
    );
  }
  passwordType1: string = 'password';
  passwordIcon1: string = 'eye-off-outline';

  passwordType2: string = 'password';
  passwordIcon2: string = 'eye-off-outline';

  togglePasswordVisibility1() {
    this.passwordType1 = this.passwordType1 === 'password' ? 'text' : 'password';
    this.passwordIcon1 = this.passwordIcon1 === 'eye-off-outline' ? 'eye-outline' : 'eye-off-outline';
  }

  togglePasswordVisibility2() {
    this.passwordType2 = this.passwordType2 === 'password' ? 'text' : 'password';
    this.passwordIcon2 = this.passwordIcon2 === 'eye-off-outline' ? 'eye-outline' : 'eye-off-outline';
  }
}