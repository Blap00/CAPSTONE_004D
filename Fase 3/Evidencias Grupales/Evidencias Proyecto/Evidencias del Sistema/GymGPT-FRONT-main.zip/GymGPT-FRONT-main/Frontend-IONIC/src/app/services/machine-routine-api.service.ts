import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable, map } from 'rxjs';

import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class MachineRoutineApiService {
  baseUrl: string = environment.baseUrl;
  private apiUrl = this.baseUrl + 'api/v-1/'; // Cambia esta URL según tu backend

  constructor(private http: HttpClient) { }
  postCameraMachine(body: any): Observable<any> {
    const token = localStorage.getItem('token');
    if (!token) {
      console.error('Token no encontrado');
    }
    return this.http.post(`${this.apiUrl}camera/scannedInfo`, body, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      }
    });
  }
  getLastMachine(id: number): Observable<any> {
    const token = localStorage.getItem('token');
    if (!token) {
      console.error('Token no encontrado');
    }
    return this.http.get(`${this.apiUrl}camera/infoBy/${id}`, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      }
    });
  }

  //**ROUTINE INFO */
  postRoutine(body: any): Observable<any> {
    const token = localStorage.getItem('token');
    if (!token) {
      console.error('Token no encontrado');
    }

    return this.http.post(`${this.apiUrl}routine/loadinfo/`, body, {

      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      }
    });
  }
  postLastRoutine(body: any): Observable<any> {
    const token = localStorage.getItem('token');
    if (!token) {
      console.error('Token no encontrado');
    }
    return this.http.post(`${this.apiUrl}routine/infoBy/`, body, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      }
    });
  }

  //GET INFO FROM ROUTINE (HOURS; EXCERCISE & NAME)
  getRoutineData(id: number): Observable<any> {
    const token = localStorage.getItem('token');
    if (!token) {
      console.error('Token no encontrado');
      return new Observable<any>();  // Retorna un observable vacío si no hay token
    }
    return this.http.get(`${this.apiUrl}routine/infoBy/${id}/all`, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      }
    })
  }
  // Get ROUTINES BUCKET LIST

  getBucketList(): Observable<string[]> {
    const token = localStorage.getItem('token');
    if (!token) {
      console.error('Token no encontrado');
      return new Observable<string[]>();  // Retorna un observable vacío si no hay token
    }

    return this.http.get<{ routines: { name: string }[] }>(`${this.apiUrl}routinesGlobal`, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      }
    }).pipe(
      map(response => response.routines.map(routine => routine.name))
    );
  }
}