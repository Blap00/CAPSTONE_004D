import { Component, OnInit } from '@angular/core';
import {
  MenuController,
  NavController,
  ToastController,
  LoadingController,
} from '@ionic/angular';
import { ServiceUsuarioService } from '../services/service-usuario.service';
import { AppComponent } from '../app.component';
import { environment } from '../../environments/environment';
import { AdmobService } from '../services/admob.service'; // Importa tu servicio AdMob

@Component({
  selector: 'app-config',
  templateUrl: './config.page.html',
  styleUrls: ['./config.page.scss'],
})
export class ConfigPage implements OnInit {
  isLoading: boolean = false;
  user: any;
  notificationsEnabled: boolean = false;
  darkModeEnabled: boolean = false;
  errorMessage = '';
  baseUrl: string = environment.baseUrl;
  componente = this.appComponent.componentes;
  media_url = '';
  statusImage: boolean = false;

  constructor(
    private navController: NavController,
    private appComponent: AppComponent,
    private menuController: MenuController,
    private toastController: ToastController,
    private loadingController: LoadingController,
    private userService: ServiceUsuarioService,
    private admobService: AdmobService,
  ) {}

  ngOnInit() {
    this.loadUser();
  }

  loadUser() {
    const userId = localStorage.getItem('userId');
    if (userId) {
      const refreshToken = localStorage.getItem('token');
      this.userService.refreshedToken(refreshToken).subscribe(
        (tokenResponse: any) => {
          localStorage.setItem('token', tokenResponse.access);
        },
        (error) => {
          console.error('Error al obtener el token', error);
          this.errorMessage = 'Error al obtener el token.';
        }
      );

      this.userService.getUser(parseInt(userId)).subscribe(
        (data) => {
          this.user = data;
          this.media_url = this.user.user.image;
          this.statusImage = true;
          if (this.user.user.image != '' && this.media_url != undefined) {

            this.user.user.image = this.baseUrl + this.media_url;
          }else{
            this.user.user.image = `${this.baseUrl}${this.media_url}media/ryan.jpg`
          }

        },
        (error) => {
          console.error('Error al obtener los datos del usuario:', error);
        }
      );
    } else {
      console.error('No hay un usuario conectado');
    }
  }

  // Lógica para activar/desactivar notificaciones
  toggleNotifications() {
    console.log(
      `Notificaciones ${this.notificationsEnabled ? 'activadas' : 'desactivadas'}`
    );
    // Implementa la lógica para habilitar/deshabilitar notificaciones
  }

  // Lógica para cambiar el modo oscuro/claro
  toggleDarkMode() {
    document.body.classList.toggle('dark', this.darkModeEnabled);
    console.log(
      `Modo oscuro ${this.darkModeEnabled ? 'habilitado' : 'deshabilitado'}`
    );
  }

  // Lógica para iniciar el proceso de suscripción
  startSubscription() {
    console.log('Iniciando el proceso de suscripción...');
    // Implementa la lógica de suscripción aquí
  }
  async showAd(){
    this.admobService.initializeAdMob().then(() => {
      this.admobService.showInterstitial();
    }).catch(error => {
      console.error('Error al inicializar AdMob o mostrar el banner:', error);
    });
  }
  async mostrarMenu() {
    this.menuController.open('first');
    this.menuController.enable(true, 'first');
  }
}