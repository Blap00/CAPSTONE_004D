import { Component, OnInit } from '@angular/core';
import { ServiceUsuarioService } from '../services/service-usuario.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MenuController, NavController, ToastController, LoadingController } from '@ionic/angular';
import { AppComponent } from '../app.component';
import { environment } from '../../environments/environment';
@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.page.html',
  styleUrls: ['./edit-user.page.scss'],
})
export class EditUserPage implements OnInit {

  user: any;
  editForm: FormGroup;
  errorMessage = '';
  selectedFile: File | null = null;  // Variable para almacenar la imagen seleccionada
  baseUrl: string = environment.baseUrl;

  isModalOpen = false;
  confirmPassword: string = '';
  isLoading:boolean=false;

  constructor(
    private userService: ServiceUsuarioService,
    private formBuilder: FormBuilder,
    private menuController: MenuController,
    private navController: NavController,
    private appComponent: AppComponent,
    private toastController: ToastController,
    private loadingController: LoadingController
  ) {
    this.editForm = this.formBuilder.group({
      nombreCompleto: ['', [Validators.required]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      edad: ['', [Validators.required]],
      altura: ['', [Validators.required]],
      peso: ['', [Validators.required]]
    });
  }
  async presentToast(message: string, color: string = 'success') {
    const toast = await this.toastController.create({
      message,
      duration: 2000,
      color,
      position: 'bottom'
    });
    await toast.present();
  }
  async presentLoading() {
    const loading = await this.loadingController.create({
      message: 'Actualizando...',
      spinner: 'circles'
    });
    await loading.present();
  }
  
  async dismissLoading() {
    await this.loadingController.dismiss();
  }
  componente = this.appComponent.componentes;
  media_url = '';
  statusImage: boolean = false;

  ngOnInit() {
    const userId = localStorage.getItem('userId');
    if (userId) {
      const refreshToken = localStorage.getItem('token');
      this.userService.refreshedToken(refreshToken).subscribe(
        (tokenResponse: any) => {
          const token = tokenResponse.access; // Ajusta según tu respuesta
          // const refreshToken = tokenResponse.refresh;
          localStorage.setItem('token', token);
          // localStorage.setItem('refresh', refreshToken);
        },
        (error) => {
          console.error('Error al obtener el token', error);
          this.errorMessage = 'Error al obtener el token.'; // TO FIX
        }
      )
      this.userService.getUser(parseInt(userId)).subscribe(
        data => {
          this.user = data;
          this.media_url = this.user.user.image;
          console.log(this.baseUrl)
          console.log(this.media_url)
          this.statusImage = true;
          if(this.user.user.image!='' && this.media_url!=undefined){
            this.user.user.image = `${this.baseUrl}${this.media_url}`;
          } else {
            console.log("La imagen no se encontró!");
            this.user.user.image = `${this.baseUrl}${this.media_url}media/ryan.jpg`;
          }
          this.populateForm();
          console.log('Datos del usuario:', this.user);
        },
        error => {
          console.error('Error al obtener los datos del usuario:', error);
        }
      );
    } else {
      console.error('No hay un usuario conectado');
    }
  }
  openModal() {
    console.log("Modal Abierto!")
    this.isModalOpen = true;
  }

  closeModal() {
    this.isModalOpen = false;
    this.confirmPassword = '';
  }



  onFileSelected(event: any) {
    const file = event.target.files[0];
    if (file) {
      this.selectedFile = file;
      this.user.user.image = URL.createObjectURL(file); // Actualiza la imagen en la vista
      console.log('Archivo seleccionado:', file);
    }
  }
  selectImage() {
    const imageInput = document.getElementById('imageInput') as HTMLInputElement;
    if (imageInput) {
      imageInput.click();
    }
  } 


  populateForm() {
    if (this.user) {
      const fullName = `${this.user.user.first_name} ${this.user.user.last_name}`;

      this.editForm.patchValue({
        nombreCompleto: fullName,
        edad: this.user.user.age,
        altura: this.user.user.height,
        peso: this.user.user.weight
      });
    }
  }

  confirmIdentity() {
    if (this.editForm.get('password')?.value) {
      console.log("Confirmación de identidad en proceso...");
      this.updateUser(this.editForm.get('password')?.value); // Llama a la función de actualización con la contraseña actual
      this.closeModal();
    } else {
      this.errorMessage = 'Debe ingresar su contraseña actual para confirmar.';
    }
  }
  
  async updateUser(currentPassword: string) {
    if (this.editForm.invalid) {
      this.errorMessage = 'Por favor, complete todos los campos correctamente.';
      await this.presentToast(this.errorMessage, 'danger');
      return;
    }
  
    await this.presentLoading(); // Mostrar indicador de carga
  
    const formData = new FormData();
    const formValues = this.editForm.value;
    const nombres = formValues.nombreCompleto.trim().split(' ');
    const firstName = nombres[0];
    const lastName = nombres.length > 1 ? nombres.slice(1).join(' ') : '';
  
    formData.append('first_name', firstName);
    formData.append('last_name', lastName);
    formData.append('current_password', currentPassword);
    formData.append('age', formValues.edad);
    formData.append('height', formValues.altura);
    formData.append('weight', formValues.peso);
  
    const imageInput = document.getElementById('imageInput') as HTMLInputElement;
    if (imageInput && imageInput.files && imageInput.files.length > 0) {
      formData.append('image', imageInput.files[0]);
    } else {
      formData.append('image', '');
    }
  
    this.userService.updateUserWithImage(formData).subscribe(
      async (response) => {
        await this.dismissLoading(); // Ocultar indicador de carga
        await this.presentToast('Perfil actualizado exitosamente', 'success');
        this.navController.navigateForward('/user')
      },
      async (error) => {
        await this.dismissLoading(); // Ocultar indicador de carga
        console.error('Error al actualizar el perfil', error);
        const errorMsg = error.error?.current_password?.[0] || 'Error al actualizar el perfil';
        this.errorMessage = errorMsg;
        await this.presentToast(this.errorMessage, 'danger');
      }
    );
  }
  
  mostrarMenu() {
    this.menuController.open('first');
    this.menuController.enable(true, 'first');
  }
}