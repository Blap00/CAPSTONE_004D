import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ServiceUsuarioService } from '../services/service-usuario.service';
import { MenuController, NavController } from '@ionic/angular';
import { AppComponent } from '../app.component';
import { environment } from '../../environments/environment';
import { AdmobService } from '../services/admob.service';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.page.html',
  styleUrls: ['./inicio.page.scss'],
  encapsulation: ViewEncapsulation.ShadowDom,
})
export class InicioPage implements OnInit {
  subscription: boolean = false;
  user: any = {
    user: {
      id: -1,
      username: '',
      email: '',
      first_name: '',
      last_name: '',
      height: 0,
      age: 0,
      weight: 0,
      routines: [],
      image: '',
    },
  };

  componente = this.appComponent.componentes;
  media_url = '';
  statusImage: boolean = false;

  baseUrl: string = environment.baseUrl;
  htmlMessage: SafeHtml | null = null;
  htmlDisp: boolean = false;
  constructor(
    private userService: ServiceUsuarioService,
    private menuController: MenuController,
    private navController: NavController,
    private appComponent: AppComponent,
    private admobService: AdmobService,
    private sanitizer: DomSanitizer
  ) { }

  ngOnInit() {
    this.loadData();
    this.initializeApp();
    this.loadLastRoutine();
  }

  async loadLastRoutine() {
    const userId = localStorage.getItem('userId');
    if (userId) {
      this.userService.getLastRoutine(parseInt(userId)).subscribe(
        (data) => {
          this.htmlDisp = true;
          const generatedHtml = data.GeneratedRoutine;
          if (generatedHtml && generatedHtml.trim() == 'No definido') {
            // Manejo del caso cuando no hay HTML válido
            this.htmlDisp = false;
            console.warn('Contenido HTML no válido o no definido.');

          } else {
            this.htmlMessage = this.sanitizer.bypassSecurityTrustHtml(generatedHtml);
            console.log('HTML Generado:', this.htmlMessage);
          }        
        },
        (error) => {
          this.htmlDisp = false;
          console.error('Error al cargar la última rutina:', error);
        }
      );
    }
  }

  async loadData() {
    const userId = localStorage.getItem('userId');
    if (userId) {
      this.userService.getUser(parseInt(userId)).subscribe(
        (data) => {
          this.user = data;
          this.media_url = this.user.user.image;
          this.statusImage = true;
          
          if (this.media_url) {
            this.user.user.image = `${this.baseUrl}${this.media_url}`;
          } else {
            this.user.user.image = `${this.baseUrl}/media/ryan.jpg`;
          }

          if (this.user.user.subscription) {
            this.subscription = true;
          }
          console.log('Datos del usuario:', this.user);
        },
        (error) => {
          console.error('Error al obtener los datos del usuario:', error);
        }
      );
    } else {
      console.error('No hay un usuario conectado');
    }
  }

  ionViewDidEnter() {
    this.admobService.resumeBanner();
  }

  async initializeApp() {
    try {
      await this.admobService.initializeAdMob();
      this.admobService.showBanner();
    } catch (error) {
      console.error('Error al inicializar AdMob o mostrar el banner:', error);
    }
  }

  ionViewDidLeave() {
    this.admobService.hideBanner();
  }

  mostrarMenu() {
    this.admobService.hideBanner();
    this.menuController.open('first');
  }

  cerrarMenu() {
    this.menuController.close('first').then(() => {
      this.admobService.showBanner();
    });
  }
}
