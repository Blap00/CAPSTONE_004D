package org.GymGPT.GymGPT;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
